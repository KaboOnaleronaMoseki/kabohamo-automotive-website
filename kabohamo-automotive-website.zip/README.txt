KABOHAMO AUTOMOTIVE WEBSITE

Files:
- index.html
- about.html
- services.html
- enquiry.html
- contact.html
- css/style.css
- js/script.js
- images/ (add your real logo/photos here)

How to run:
1. Open the folder in VS Code.
2. Add your real images to the images folder.
3. Open index.html with Live Server, or double-click index.html.

Important before publishing:
- Replace placeholder team information with verified names/roles.
- Confirm the company's current phone numbers, hours, email and services.
- Add a second verified Kabohamo location to the Contact page to satisfy the assignment requirement.
- Connect the forms to a real backend/email service.
- Replace the hero background with an approved business image/logo.
