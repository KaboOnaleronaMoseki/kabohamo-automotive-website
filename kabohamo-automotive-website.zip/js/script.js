document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }

  document.querySelectorAll(".faq-question").forEach(btn => {
    btn.addEventListener("click", () => {
      const answer = btn.nextElementSibling;
      answer.classList.toggle("open");
      btn.querySelector("span").textContent = answer.classList.contains("open") ? "−" : "+";
    });
  });

  const params = new URLSearchParams(window.location.search);
  const service = params.get("service");
  const type = params.get("type");
  const serviceSelect = document.getElementById("service");
  const businessFields = document.getElementById("businessFields");

  if (serviceSelect && service) {
    const map = {
      licensing: "licensing",
      registration: "registration",
      plates: "plates",
      logistics: "logistics"
    };
    if (map[service]) serviceSelect.value = map[service];
  }
  if (serviceSelect && businessFields) {
    const updateBusinessFields = () => {
      businessFields.classList.toggle("hidden", serviceSelect.value !== "business");
    };
    serviceSelect.addEventListener("change", updateBusinessFields);
    updateBusinessFields();
    if (type === "business") serviceSelect.value = "business";
  }

  const enquiryForm = document.getElementById("enquiryForm");
  if (enquiryForm) {
    enquiryForm.addEventListener("submit", e => {
      e.preventDefault();
      const message = document.getElementById("formMessage");
      message.textContent = "Demo submitted successfully. Connect this form to email, a database or backend before publishing.";
      enquiryForm.reset();
      if (businessFields) businessFields.classList.add("hidden");
    });
  }

  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", e => {
      e.preventDefault();
      document.getElementById("contactMessageStatus").textContent =
        "Demo message submitted successfully. Connect this form to your chosen email or backend service before publishing.";
      contactForm.reset();
    });
  }
});
